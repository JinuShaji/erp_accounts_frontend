import React from 'react';
import { useCallback, useEffect, useMemo, useState } from 'react';

const API = 'http://localhost:5000/api';
const today = () => new Date().toISOString().slice(0, 10);
const defaultDueDate = () => {
  const date = new Date();
  date.setDate(date.getDate() + 14);
  return date.toISOString().slice(0, 10);
};
const money = (value) => new Intl.NumberFormat('en-IN', {
  style: 'currency', currency: 'INR', maximumFractionDigits: 2
}).format(Number(value || 0));
const dateLabel = (value) => value ? new Date(`${String(value).slice(0, 10)}T00:00:00`).toLocaleDateString('en-IN') : '—';
const emptyItem = () => ({ description: '', quantity: '1', unit_price: '', tax_rate: '0' });

async function request(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    ...options,
    headers: {
      ...(options.body ? { 'Content-Type': 'application/json' } : {}),
      ...options.headers
    }
  });
  let data;
  try {
    data = await response.json();
  } catch {
    data = {};
  }
  if (!response.ok) throw new Error(data.message || `Request failed (${response.status})`);
  return data;
}

function Alert({ error, notice }) {
  return (
    <>
      {error && <div className="alert error" role="alert">{error}</div>}
      {notice && <div className="alert success" role="status">{notice}</div>}
    </>
  );
}

function Status({ value }) {
  const label = value === 'partial' ? 'Partially paid' : value || 'Unknown';
  return <span className={`badge ${String(value || '').toLowerCase()}`}>{label}</span>;
}

export default function App() {
  const [page, setPage] = useState('invoices');
  const [invoices, setInvoices] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [outstanding, setOutstanding] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [journalEntries, setJournalEntries] = useState([]);
  const [trialBalance, setTrialBalance] = useState({ accounts: [], totals: {}, balanced: true });
  const [invoice, setInvoice] = useState(null);
  const [editingInvoice, setEditingInvoice] = useState(null);
  const [invoiceId, setInvoiceId] = useState(null);
  const [statusFilter, setStatusFilter] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const loadInvoices = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const query = statusFilter ? `?status=${encodeURIComponent(statusFilter)}` : '';
      setInvoices(await request(`/invoices${query}`));
    } catch (err) {
      setError(err.message || 'Unable to load invoices');
    } finally {
      setLoading(false);
    }
  }, [statusFilter]);

  const loadCustomers = useCallback(async () => {
    try {
      setCustomers(await request('/customers'));
    } catch (err) {
      setError(err.message || 'Unable to load customers');
    }
  }, []);

  const loadInvoice = useCallback(async (id) => {
    setLoading(true);
    setError('');
    try {
      setInvoice(await request(`/invoices/${id}`));
    } catch (err) {
      setInvoice(null);
      setError(err.message || 'Unable to load invoice');
    } finally {
      setLoading(false);
    }
  }, []);

  const loadOutstanding = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const result = await request('/payments/customer-outstanding');
      setOutstanding((result.customers || []).slice().sort((a, b) => Number(b.amount_owed) - Number(a.amount_owed)));
    } catch (err) {
      setError(err.message || 'Unable to load outstanding report');
    } finally {
      setLoading(false);
    }
  }, []);

  const loadAccounts = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      setAccounts(await request('/accounts'));
    } catch (err) {
      setError(err.message || 'Unable to load chart of accounts');
    } finally {
      setLoading(false);
    }
  }, []);

  const loadJournalEntries = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      setJournalEntries(await request('/journal_entries'));
    } catch (err) {
      setError(err.message || 'Unable to load journal entries');
    } finally {
      setLoading(false);
    }
  }, []);

  const loadTrialBalance = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      setTrialBalance(await request('/report/trial-balance'));
    } catch (err) {
      setError(err.message || 'Unable to load trial balance');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadInvoices(); }, [loadInvoices]);
  useEffect(() => { loadCustomers(); }, [loadCustomers]);
  useEffect(() => {
    if (page === 'detail' && invoiceId) loadInvoice(invoiceId);
  }, [page, invoiceId, loadInvoice]);
  useEffect(() => {
    if (page === 'report') loadOutstanding();
  }, [page, loadOutstanding]);
  useEffect(() => {
    if (page === 'accounts') loadAccounts();
    if (page === 'journals') loadJournalEntries();
    if (page === 'trialBalance') loadTrialBalance();
  }, [page, loadAccounts, loadJournalEntries, loadTrialBalance]);

  function navigate(nextPage) {
    setError('');
    setNotice('');
    if (nextPage !== 'create') setEditingInvoice(null);
    setPage(nextPage);
  }

  function editDraft(draft) {
    setEditingInvoice(draft);
    setError('');
    setNotice('');
    setPage('create');
  }

  function showInvoice(id) {
    setInvoiceId(id);
    setInvoice(null);
    setError('');
    setNotice('');
    setPage('detail');
  }

  async function issueInvoice(id) {
    setError('');
    setNotice('');
    setLoading(true);
    try {
      const result = await request(`/invoices/${id}/issue`, { method: 'PATCH' });
      setNotice(result.message || 'Invoice issued.');
      await loadInvoice(id);
      await loadInvoices();
    } catch (err) {
      setError(err.message || 'Unable to issue invoice');
    } finally {
      setLoading(false);
    }
  }

  const pageTitle = page === 'create' ? 'Create invoice'
    : page === 'detail' ? 'Invoice details'
      : page === 'report' ? 'Outstanding report'
        : page === 'accounts' ? 'Chart of accounts'
          : page === 'journals' ? 'Journal entries'
            : page === 'trialBalance' ? 'Trial balance' : 'Invoices';
  const pageDescription = page === 'create' ? 'Add a customer and line items to prepare an invoice.'
    : page === 'detail' ? 'Review invoice items, payment history, and record a payment.'
      : page === 'report' ? 'Customers with an outstanding balance, ranked largest first.'
        : page === 'accounts' ? 'Account codes, types, and posted balances.'
          : page === 'journals' ? 'Posted double-entry activity from invoices and payments.'
            : page === 'trialBalance' ? 'Every account with debit and credit activity and balances.'
              : 'Create, review, and track customer invoices.';

  return (
    <main className="container">
      <header className="page-header">
        <div>
          <p className="eyebrow">ERP / ACCOUNTS RECEIVABLE</p>
          <h1>{pageTitle}</h1>
          <p className="subtitle">{pageDescription}</p>
        </div>
        <span className="status">● Invoice management</span>
      </header>

      <nav className="nav-tabs" aria-label="Accounting pages">
        <button className={page === 'invoices' || page === 'detail' ? 'active' : ''} onClick={() => navigate('invoices')}>Invoices</button>
        <button className={page === 'create' ? 'active' : ''} onClick={() => navigate('create')}>Create invoice</button>
        <button className={page === 'report' ? 'active' : ''} onClick={() => navigate('report')}>Outstanding report</button>
        <button className={page === 'accounts' ? 'active' : ''} onClick={() => navigate('accounts')}>Accounts</button>
        <button className={page === 'journals' ? 'active' : ''} onClick={() => navigate('journals')}>Journal entries</button>
        <button className={page === 'trialBalance' ? 'active' : ''} onClick={() => navigate('trialBalance')}>Trial balance</button>
      </nav>

      <Alert error={error} notice={notice} />

      {page === 'invoices' && (
        <InvoiceList
          invoices={invoices}
          loading={loading}
          statusFilter={statusFilter}
          setStatusFilter={setStatusFilter}
          onCreate={() => {
            setEditingInvoice(null);
            navigate('create');
          }}
          onOpen={showInvoice}
          onRefresh={loadInvoices}
        />
      )}
      {page === 'create' && (
        <CreateInvoice
          customers={customers}
          initialInvoice={editingInvoice}
          onCancel={() => navigate('invoices')}
          onCreated={async (id, issued, updated) => {
            setEditingInvoice(null);
            setInvoiceId(id);
            setInvoice(null);
            setPage('detail');
            await loadInvoices();
            if (issued) {
              try {
                const result = await request(`/invoices/${id}/issue`, { method: 'PATCH' });
                setNotice(result.message || 'Invoice issued.');
                await loadInvoice(id);
              } catch (err) {
                setError(`Draft saved, but issuing failed: ${err.message}`);
              }
            } else {
              setNotice(updated ? 'Draft invoice updated.' : 'Invoice saved as draft.');
            }
          }}
          onError={setError}
        />
      )}
      {page === 'detail' && (
        <InvoiceDetails
          invoice={invoice}
          loading={loading}
          onBack={() => navigate('invoices')}
          onIssue={issueInvoice}
          onEdit={editDraft}
          onDelete={async (id) => {
            setError('');
            try {
              const result = await request(`/invoices/${id}`, { method: 'DELETE' });
              setNotice(result.message || 'Draft invoice deleted.');
              setPage('invoices');
              setInvoice(null);
              await loadInvoices();
            } catch (err) {
              setError(err.message || 'Unable to delete invoice');
            }
          }}
          onPaymentSaved={async (message) => {
            setNotice(message);
            await loadInvoice(invoiceId);
            await loadInvoices();
          }}
          onError={setError}
        />
      )}
      {page === 'report' && <OutstandingReport rows={outstanding} loading={loading} onRefresh={loadOutstanding} />}
      {page === 'accounts' && <AccountsScreen accounts={accounts} loading={loading} onRefresh={loadAccounts} />}
      {page === 'journals' && <JournalEntriesScreen entries={journalEntries} loading={loading} onRefresh={loadJournalEntries} />}
      {page === 'trialBalance' && <TrialBalanceScreen report={trialBalance} loading={loading} onRefresh={loadTrialBalance} />}
      <footer>ERP Accounts Receivable · React + Express</footer>
    </main>
  );
}

function InvoiceList({ invoices, loading, statusFilter, setStatusFilter, onCreate, onOpen, onRefresh }) {
  return (
    <section className="panel">
      <div className="panel-heading">
        <div><h2>Invoice list</h2><p>{invoices.length} invoice{invoices.length === 1 ? '' : 's'}</p></div>
        <div className="form-actions">
          <button className="button secondary" onClick={onRefresh} type="button">Refresh</button>
          <button className="button primary" onClick={onCreate} type="button">+ New invoice</button>
        </div>
      </div>
      <div className="filters invoice-filters">
        <label>Filter by status
          <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
            <option value="">All statuses</option>
            <option value="draft">Draft</option>
            <option value="issued">Issued</option>
            <option value="partial">Partially paid</option>
            <option value="paid">Paid</option>
          </select>
        </label>
      </div>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Invoice number</th><th>Customer</th><th>Date</th><th>Total</th><th>Amount paid</th><th>Balance due</th><th>Status</th></tr></thead>
          <tbody>
            {loading ? <tr><td colSpan="7" className="empty">Loading invoices…</td></tr>
              : invoices.length === 0 ? <tr><td colSpan="7" className="empty">No invoices found.</td></tr>
                : invoices.map((row) => (
                  <tr key={row.id} className="clickable-row" onClick={() => onOpen(row.id)} tabIndex="0"
                    onKeyDown={(event) => { if (event.key === 'Enter') onOpen(row.id); }}>
                    <td className="product-name">{row.unique_invoice_no}</td>
                    <td>{row.customer_name}</td>
                    <td>{dateLabel(row.invoice_date)}</td>
                    <td>{money(row.total)}</td>
                    <td>{money(row.paid_amount)}</td>
                    <td>{money(row.balance_due)}</td>
                    <td><Status value={row.status} /></td>
                  </tr>
                ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function CreateInvoice({ customers, initialInvoice, onCancel, onCreated, onError }) {
  const [customerId, setCustomerId] = useState(initialInvoice ? String(initialInvoice.cusomer_id) : '');
  const [invoiceDate, setInvoiceDate] = useState(initialInvoice ? String(initialInvoice.invoice_date).slice(0, 10) : today);
  const [dueDate, setDueDate] = useState(initialInvoice ? String(initialInvoice.due_date).slice(0, 10) : defaultDueDate);
  const [items, setItems] = useState(initialInvoice
    ? initialInvoice.items.map((item) => ({
      description: item.description,
      quantity: String(item.quantity),
      unit_price: String(item.unit_price),
      tax_rate: String(item.tax_rate ?? 0)
    }))
    : [emptyItem()]);
  const [saving, setSaving] = useState(false);

  const totals = useMemo(() => items.reduce((result, item) => {
    const quantity = Number(item.quantity) || 0;
    const price = Number(item.unit_price) || 0;
    const rate = Number(item.tax_rate) || 0;
    const lineSubtotal = Math.round((quantity * price + Number.EPSILON) * 100) / 100;
    const lineTax = Math.round((lineSubtotal * rate / 100 + Number.EPSILON) * 100) / 100;
    result.subtotal += lineSubtotal;
    result.tax += lineTax;
    return result;
  }, { subtotal: 0, tax: 0 }), [items]);
  const grandTotal = Math.round((totals.subtotal + totals.tax + Number.EPSILON) * 100) / 100;

  function changeItem(index, field, value) {
    setItems((current) => current.map((item, itemIndex) => itemIndex === index ? { ...item, [field]: value } : item));
  }

  async function submit(event, issue) {
    event.preventDefault();
    onError('');
    if (!invoiceDate || !dueDate || dueDate < invoiceDate) {
      onError('Choose valid invoice and due dates. The due date cannot be before the invoice date.');
      return;
    }
    if (!customerId) {
      onError('Please choose a customer.');
      return;
    }
    if (items.some((item) => !item.description.trim() || item.quantity === '' || item.unit_price === '' || Number(item.quantity) <= 0 ||
      Number(item.unit_price) < 0 || Number(item.tax_rate) < 0 || Number(item.tax_rate) > 100 ||
      !Number.isFinite(Number(item.quantity)) || !Number.isFinite(Number(item.unit_price)) ||
      !Number.isFinite(Number(item.tax_rate)))) {
      onError('Enter a description and valid quantity, unit price, and tax rate for every line item.');
      return;
    }
    setSaving(true);
    try {
      const result = await request(initialInvoice ? `/invoices/${initialInvoice.id}` : '/invoices', {
        method: initialInvoice ? 'PUT' : 'POST',
        body: JSON.stringify({
          cusomer_id: Number(customerId),
          invoice_date: invoiceDate,
          due_date: dueDate,
          items: items.map((item) => ({
            description: item.description.trim(),
            quantity: Number(item.quantity),
            unit_price: Number(item.unit_price),
            tax_rate: Number(item.tax_rate)
          }))
        })
      });
      await onCreated(result.invoice_id || initialInvoice.id, issue, Boolean(initialInvoice));
    } catch (err) {
      onError(err.message || 'Unable to create invoice');
    } finally {
      setSaving(false);
    }
  }

  return (
    <form className="panel" onSubmit={(event) => submit(event, false)}>
      <div className="panel-heading"><div><h2>{initialInvoice ? `Edit draft ${initialInvoice.unique_invoice_no}` : 'Invoice information'}</h2><p>Choose the customer and invoice dates.</p></div></div>
      {customers.length === 0 && <div className="alert error">No customers are available. Add a customer before creating an invoice.</div>}
      <div className="form-grid">
        <label>Customer
          <select value={customerId} onChange={(event) => setCustomerId(event.target.value)} required>
            <option value="">Choose a customer…</option>
            {customers.map((customer) => <option key={customer.id} value={customer.id}>{customer.name}</option>)}
          </select>
        </label>
        <label>Invoice date
          <input type="date" value={invoiceDate} onChange={(event) => setInvoiceDate(event.target.value)} required />
        </label>
        <label>Due date
          <input type="date" value={dueDate} min={invoiceDate} onChange={(event) => setDueDate(event.target.value)} required />
        </label>
      </div>

      <div className="panel-heading line-items-heading"><div><h2>Line items</h2><p>Totals update as you edit the rows.</p></div>
        <button className="button secondary" type="button" onClick={() => setItems((current) => [...current, emptyItem()])}>+ Add line</button>
      </div>
      <div className="table-wrap">
        <table className="line-items-table">
          <thead><tr><th>Description</th><th>Quantity</th><th>Unit price</th><th>Tax %</th><th>Line total</th><th></th></tr></thead>
          <tbody>{items.map((item, index) => {
            const subtotal = Math.round((Number(item.quantity || 0) * Number(item.unit_price || 0) + Number.EPSILON) * 100) / 100;
            const tax = Math.round((subtotal * Number(item.tax_rate || 0) / 100 + Number.EPSILON) * 100) / 100;
            const lineTotal = subtotal + tax;
            return <tr key={index}>
              <td><input aria-label={`Description ${index + 1}`} value={item.description} onChange={(event) => changeItem(index, 'description', event.target.value)} maxLength="255" placeholder="Service or product" required /></td>
              <td><input aria-label={`Quantity ${index + 1}`} type="number" min="0.01" step="any" value={item.quantity} onChange={(event) => changeItem(index, 'quantity', event.target.value)} required /></td>
              <td><input aria-label={`Unit price ${index + 1}`} type="number" min="0" step="0.01" value={item.unit_price} onChange={(event) => changeItem(index, 'unit_price', event.target.value)} required /></td>
              <td><input aria-label={`Tax rate ${index + 1}`} type="number" min="0" max="100" step="0.01" value={item.tax_rate} onChange={(event) => changeItem(index, 'tax_rate', event.target.value)} /></td>
              <td className="line-total">{money(lineTotal)}</td>
              <td><button className="icon-button remove-button" type="button" aria-label={`Remove line ${index + 1}`} title="Remove line" disabled={items.length === 1} onClick={() => setItems((current) => current.filter((_, itemIndex) => itemIndex !== index))}>×</button></td>
            </tr>;
          })}</tbody>
        </table>
      </div>
      <div className="totals-box">
        <div><span>Subtotal</span><strong>{money(totals.subtotal)}</strong></div>
        <div><span>Tax</span><strong>{money(totals.tax)}</strong></div>
        <div className="grand-total"><span>Grand total</span><strong>{money(grandTotal)}</strong></div>
      </div>
      <div className="form-actions end-actions">
        <button className="button secondary" type="button" onClick={onCancel}>Cancel</button>
        <button className="button secondary" type="submit" disabled={saving || customers.length === 0}>{saving ? 'Saving…' : initialInvoice ? 'Save draft changes' : 'Save as draft'}</button>
        <button className="button primary" type="button" disabled={saving || customers.length === 0} onClick={(event) => submit(event, true)}>{saving ? 'Saving…' : initialInvoice ? 'Save changes & issue' : 'Save & issue'}</button>
      </div>
    </form>
  );
}

function InvoiceDetails({ invoice, loading, onBack, onIssue, onEdit, onDelete, onPaymentSaved, onError }) {
  const [payment, setPayment] = useState({
    date: today(), amount: '', payment_method: 'Bank transfer', reference_no: ''
  });
  const [saving, setSaving] = useState(false);

  async function recordPayment(event) {
    event.preventDefault();
    onError('');
    setSaving(true);
    try {
      const result = await request('/payments', {
        method: 'POST',
        body: JSON.stringify({
          cusomer_id: Number(invoice.cusomer_id),
          invoice_id: Number(invoice.id),
          date: payment.date,
          amount: Number(payment.amount),
          payment_method: payment.payment_method,
          reference_no: payment.reference_no.trim() || null
        })
      });
      setPayment((current) => ({ ...current, amount: '', reference_no: '' }));
      await onPaymentSaved(result.message || 'Payment recorded successfully.');
    } catch (err) {
      onError(err.message || 'Payment was rejected. Please try again.');
    } finally {
      setSaving(false);
    }
  }

  if (loading && !invoice) return <section className="panel empty">Loading invoice…</section>;
  if (!invoice) return <section className="panel empty">Invoice could not be displayed. Use Invoices to go back.</section>;

  const items = invoice.items || [];
  const payments = invoice.payments || [];
  const canPay = ['issued', 'partial'].includes(invoice.status) && Number(invoice.balance_due) > 0;

  return (
    <>
      <section className="panel">
        <div className="panel-heading detail-heading">
          <div><button className="text-button back-button" onClick={onBack} type="button">← Back to invoices</button>
            <h2>{invoice.unique_invoice_no}</h2><p>{invoice.customer_name} · Invoice date {dateLabel(invoice.invoice_date)} · Due {dateLabel(invoice.due_date)}</p></div>
          <div className="detail-actions"><Status value={invoice.status} />
            {invoice.status === 'draft' && <>
              <button className="button secondary" type="button" disabled={loading} onClick={() => onEdit(invoice)}>Edit draft</button>
              <button className="button danger-button" type="button" disabled={loading} onClick={() => {
                if (window.confirm(`Delete draft ${invoice.unique_invoice_no}? This cannot be undone.`)) onDelete(invoice.id);
              }}>Delete draft</button>
            </>}
            {invoice.status === 'draft' && <button className="button primary" type="button" disabled={loading} onClick={() => onIssue(invoice.id)}>Issue invoice</button>}
          </div>
        </div>
        <div className="summary-grid">
          <div><span>Subtotal</span><strong>{money(invoice.subtotal)}</strong></div>
          <div><span>Tax</span><strong>{money(invoice.tax_amount)}</strong></div>
          <div><span>Total</span><strong>{money(invoice.total)}</strong></div>
          <div><span>Paid</span><strong>{money(invoice.paid_amount)}</strong></div>
          <div><span>Balance due</span><strong>{money(invoice.balance_due)}</strong></div>
        </div>
      </section>

      <section className="panel">
        <div className="panel-heading"><div><h2>Line items</h2><p>Details recorded on this invoice.</p></div></div>
        <div className="table-wrap">
          <table><thead><tr><th>Description</th><th>Quantity</th><th>Unit price</th><th>Tax %</th><th>Line total</th></tr></thead>
            <tbody>{items.length === 0 ? <tr><td colSpan="5" className="empty">No line items.</td></tr> : items.map((item) => (
              <tr key={item.id}><td className="product-name">{item.description}</td><td>{item.quantity}</td><td>{money(item.unit_price)}</td><td>{Number(item.tax_rate)}%</td><td>{money(item.line_total)}</td></tr>
            ))}</tbody>
          </table>
        </div>
      </section>

      <section className="panel">
        <div className="panel-heading"><div><h2>Payment history</h2><p>{payments.length} payment{payments.length === 1 ? '' : 's'} recorded</p></div></div>
        <div className="table-wrap">
          <table><thead><tr><th>Date</th><th>Amount</th><th>Method</th><th>Reference</th></tr></thead>
            <tbody>{payments.length === 0 ? <tr><td colSpan="4" className="empty">No payments recorded yet.</td></tr> : payments.map((item) => (
              <tr key={item.id}><td>{dateLabel(item.date)}</td><td>{money(item.amount)}</td><td>{item.payment_method}</td><td>{item.reference_no || '—'}</td></tr>
            ))}</tbody>
          </table>
        </div>
      </section>

      {canPay && <section className="panel">
        <div className="panel-heading"><div><h2>Record a payment</h2><p>Balance due: <strong>{money(invoice.balance_due)}</strong></p></div></div>
        <form className="form-grid payment-form" onSubmit={recordPayment}>
          <label>Payment date<input type="date" value={payment.date} onChange={(event) => setPayment({ ...payment, date: event.target.value })} required /></label>
          <label>Amount (₹)<input type="number" min="0.01" max={invoice.balance_due} step="0.01" value={payment.amount} onChange={(event) => setPayment({ ...payment, amount: event.target.value })} required /></label>
          <label>Payment method<select value={payment.payment_method} onChange={(event) => setPayment({ ...payment, payment_method: event.target.value })}>
            <option>Bank transfer</option><option>Cash</option><option>Card</option><option>UPI</option><option>Cheque</option><option>Other</option>
          </select></label>
          <label>Reference number (optional)<input value={payment.reference_no} onChange={(event) => setPayment({ ...payment, reference_no: event.target.value })} maxLength="100" placeholder="Transaction or cheque number" /></label>
          <div className="form-actions payment-action"><button className="button primary" disabled={saving}>{saving ? 'Recording…' : 'Record payment'}</button></div>
        </form>
      </section>}
    </>
  );
}

function OutstandingReport({ rows, loading, onRefresh }) {
  const totalOwed = rows.reduce((sum, row) => sum + Number(row.amount_owed || 0), 0);
  return (
    <section className="panel">
      <div className="panel-heading">
        <div><h2>Customer balances</h2><p>Total outstanding: <strong>{money(totalOwed)}</strong></p></div>
        <button className="button secondary" type="button" onClick={onRefresh}>Refresh</button>
      </div>
      <div className="table-wrap">
        <table><thead><tr><th>#</th><th>Customer</th><th>Total invoiced</th><th>Total paid</th><th>Amount owed</th></tr></thead>
          <tbody>{loading ? <tr><td colSpan="5" className="empty">Loading report…</td></tr>
            : rows.length === 0 ? <tr><td colSpan="5" className="empty">No outstanding customer balances.</td></tr>
              : rows.map((row, index) => (
                <tr key={row.customer_id}><td>{index + 1}</td><td className="product-name">{row.customer_name}</td><td>{money(row.total_invoiced)}</td><td>{money(row.total_paid)}</td><td className="amount-owed">{money(row.amount_owed)}</td></tr>
              ))}</tbody>
        </table>
      </div>
    </section>
  );
}

function AccountsScreen({ accounts, loading, onRefresh }) {
  return (
    <section className="panel">
      <div className="panel-heading">
        <div><h2>Chart of accounts</h2><p>Current balances from posted journal entries.</p></div>
        <button className="button secondary" type="button" onClick={onRefresh}>Refresh</button>
      </div>
      <div className="table-wrap">
        <table><thead><tr><th>Code</th><th>Account</th><th>Type</th><th>Current balance</th></tr></thead>
          <tbody>{loading ? <tr><td colSpan="4" className="empty">Loading accounts…</td></tr>
            : accounts.length === 0 ? <tr><td colSpan="4" className="empty">No accounts found.</td></tr>
              : accounts.map((account) => (
                <tr key={account.id}>
                  <td>{account.account_code}</td>
                  <td className="product-name">{account.name}</td>
                  <td className="capitalize">{account.type}</td>
                  <td>{money(account.current_balance)} <span className="balance-side">{account.balance_side}</span></td>
                </tr>
              ))}</tbody>
        </table>
      </div>
    </section>
  );
}

function JournalEntriesScreen({ entries, loading, onRefresh }) {
  return (
    <section className="panel">
      <div className="panel-heading">
        <div><h2>Posted journal entries</h2><p>Posted entries are read-only and cannot be changed or deleted.</p></div>
        <button className="button secondary" type="button" onClick={onRefresh}>Refresh</button>
      </div>
      {loading ? <div className="empty">Loading journal entries…</div>
        : entries.length === 0 ? <div className="empty">No journal entries have been posted.</div>
          : entries.map((entry) => (
            <article className="journal-entry" key={entry.id}>
              <div className="journal-heading">
                <div><strong>Journal #{entry.id}</strong><span>{dateLabel(entry.entry_date)} · {entry.reference_type}{entry.reference_id ? ` #${entry.reference_id}` : ''}</span></div>
                <Status value={entry.status} />
              </div>
              <p className="journal-description">{entry.description}</p>
              <div className="table-wrap">
                <table className="journal-table"><thead><tr><th>Account</th><th>Description</th><th>Debit</th><th>Credit</th></tr></thead>
                  <tbody>{entry.lines.map((line) => (
                    <tr key={line.id}>
                      <td><span className="product-name">{line.account_code}</span> · {line.account_name}</td>
                      <td>{line.description || '—'}</td>
                      <td>{line.debit > 0 ? money(line.debit) : '—'}</td>
                      <td>{line.credit > 0 ? money(line.credit) : '—'}</td>
                    </tr>
                  ))}</tbody>
                </table>
              </div>
            </article>
          ))}
    </section>
  );
}

function TrialBalanceScreen({ report, loading, onRefresh }) {
  const accounts = report.accounts || [];
  const totals = report.totals || {};
  return (
    <section className="panel">
      <div className="panel-heading">
        <div><h2>Trial balance</h2><p>All chart-of-account balances. Total debits must equal total credits.</p></div>
        <div className="form-actions">
          {!loading && <span className={`balance-check ${report.balanced ? 'balanced' : 'unbalanced'}`}>
            {report.balanced ? '✓ Balanced' : 'Not balanced'}
          </span>}
          <button className="button secondary" type="button" onClick={onRefresh}>Refresh</button>
        </div>
      </div>
      <div className="table-wrap">
        <table className="trial-balance-table">
          <thead><tr><th>Code</th><th>Account</th><th>Type</th><th>Total debit</th><th>Total credit</th><th>Debit balance</th><th>Credit balance</th></tr></thead>
          <tbody>{loading ? <tr><td colSpan="7" className="empty">Loading trial balance…</td></tr>
            : accounts.length === 0 ? <tr><td colSpan="7" className="empty">No accounts found.</td></tr>
              : accounts.map((account) => (
                <tr key={account.id}>
                  <td>{account.account_code}</td>
                  <td className="product-name">{account.name}</td>
                  <td className="capitalize">{account.type}</td>
                  <td>{money(account.total_debit)}</td>
                  <td>{money(account.total_credit)}</td>
                  <td>{Number(account.debit_balance) ? money(account.debit_balance) : '—'}</td>
                  <td>{Number(account.credit_balance) ? money(account.credit_balance) : '—'}</td>
                </tr>
              ))}
          </tbody>
          {!loading && accounts.length > 0 && <tfoot><tr>
            <th colSpan="3">Grand total</th>
            <th>{money(totals.total_debit)}</th>
            <th>{money(totals.total_credit)}</th>
            <th>{money(totals.debit_balance)}</th>
            <th>{money(totals.credit_balance)}</th>
          </tr></tfoot>}
        </table>
      </div>
      {!loading && accounts.length > 0 && (
        <p className={`trial-balance-note ${report.balanced ? 'balanced' : 'unbalanced'}`}>
          {report.balanced
            ? `Debit balance total ${money(totals.debit_balance)} matches credit balance total ${money(totals.credit_balance)}.`
            : `Trial balance does not match: debit ${money(totals.debit_balance)}, credit ${money(totals.credit_balance)}.`}
        </p>
      )}
    </section>
  );
}
